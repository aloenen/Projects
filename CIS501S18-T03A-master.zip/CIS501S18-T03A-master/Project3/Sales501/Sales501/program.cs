﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sales501
{
    class program
    {
        private static void Main(string[] args)
        {
            UI ui = new UI();
            ui.run();
        }
    }
}
